export const BORDER_HEIGHT = 1;
export const MULTI_DAY_EVENT_HEIGHT = 28;
export const MONTH_NUMBER_HEIGHT = 27;
